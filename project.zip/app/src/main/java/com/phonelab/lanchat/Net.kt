package com.phonelab.lanchat

import android.content.Context
import android.net.wifi.WifiManager
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** type: T = text, I = image, A = audio, F = file */
data class Msg(
    val fromName: String,
    val type: String,
    val text: String,
    val path: String?,
    val mine: Boolean
)

data class Peer(val id: String, val name: String, val ip: String, val seen: Long)

/**
 * Peer-to-peer chat over the local network.
 * UDP broadcast = "who is here", TCP = actual messages and files.
 */
class Net(
    private val ctx: Context,
    private val myId: String,
    private val myName: String,
    private val onMessage: (Msg) -> Unit,
    private val onPeers: () -> Unit
) {
    companion object {
        const val UDP_PORT = 45454
        const val TCP_PORT = 45455
    }

    val peers = ConcurrentHashMap<String, Peer>()
    @Volatile private var running = false
    private val pool = Executors.newCachedThreadPool()
    private var lock: WifiManager.MulticastLock? = null
    private var udp: DatagramSocket? = null
    private var server: ServerSocket? = null

    fun mediaDir(): File = File(ctx.filesDir, "media").apply { mkdirs() }

    fun start() {
        running = true
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            lock = wm.createMulticastLock("lanchat").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Exception) {
        }
        pool.execute { listenUdp() }
        pool.execute { beacon() }
        pool.execute { listenTcp() }
    }

    fun stop() {
        running = false
        try { udp?.close() } catch (e: Exception) {}
        try { server?.close() } catch (e: Exception) {}
        try { lock?.release() } catch (e: Exception) {}
        pool.shutdownNow()
    }

    private fun safe(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_")

    // ---------- discovery ----------

    private fun targets(): List<InetAddress> {
        val l = mutableListOf<InetAddress>(InetAddress.getByName("255.255.255.255"))
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    val b = ia.broadcast
                    if (b != null) l.add(b)
                }
            }
        } catch (e: Exception) {
        }
        return l
    }

    private fun beacon() {
        try {
            val s = DatagramSocket()
            s.broadcast = true
            val data = "LANCHAT|$myId|${myName.replace("|", "")}".toByteArray()
            while (running) {
                for (addr in targets()) {
                    try {
                        s.send(DatagramPacket(data, data.size, addr, UDP_PORT))
                    } catch (e: Exception) {
                    }
                }
                val now = System.currentTimeMillis()
                val old = peers.values.filter { now - it.seen > 9000 }
                if (old.isNotEmpty()) {
                    old.forEach { peers.remove(it.id) }
                    onPeers()
                }
                Thread.sleep(2500)
            }
            s.close()
        } catch (e: Exception) {
        }
    }

    private fun listenUdp() {
        try {
            val s = DatagramSocket(null)
            s.reuseAddress = true
            s.bind(InetSocketAddress(UDP_PORT))
            udp = s
            val buf = ByteArray(512)
            while (running) {
                val p = DatagramPacket(buf, buf.size)
                s.receive(p)
                val parts = String(p.data, 0, p.length).split("|")
                if (parts.size >= 3 && parts[0] == "LANCHAT" && parts[1] != myId) {
                    val isNew = !peers.containsKey(parts[1])
                    peers[parts[1]] = Peer(
                        parts[1], parts[2], p.address.hostAddress ?: "", System.currentTimeMillis()
                    )
                    if (isNew) onPeers()
                }
            }
        } catch (e: Exception) {
        }
    }

    // ---------- receiving ----------

    private fun listenTcp() {
        try {
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(TCP_PORT))
            server = ss
            while (running) {
                val sock = ss.accept()
                pool.execute { handle(sock) }
            }
        } catch (e: Exception) {
        }
    }

    private fun handle(sock: Socket) {
        try {
            sock.use { s ->
                val inp = DataInputStream(BufferedInputStream(s.getInputStream()))
                inp.readUTF() // sender id (not used yet)
                val fromName = inp.readUTF()
                val type = inp.readUTF()
                val text = inp.readUTF()
                val len = inp.readLong()
                var path: String? = null
                if (len > 0) {
                    val f = File(mediaDir(), "${System.currentTimeMillis()}_${safe(text)}")
                    FileOutputStream(f).use { o ->
                        val buf = ByteArray(16384)
                        var left = len
                        while (left > 0) {
                            val n = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                            if (n < 0) break
                            o.write(buf, 0, n)
                            left -= n
                        }
                    }
                    path = f.absolutePath
                }
                onMessage(Msg(fromName, type, text, path, false))
            }
        } catch (e: Exception) {
        }
    }

    // ---------- sending ----------

    fun send(type: String, text: String, file: File?) {
        for (p in peers.values.toList()) {
            pool.execute {
                try {
                    Socket().use { s ->
                        s.connect(InetSocketAddress(p.ip, TCP_PORT), 4000)
                        val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
                        o.writeUTF(myId)
                        o.writeUTF(myName)
                        o.writeUTF(type)
                        o.writeUTF(text)
                        o.writeLong(file?.length() ?: 0L)
                        if (file != null) file.inputStream().use { it.copyTo(o) }
                        o.flush()
                    }
                } catch (e: Exception) {
                }
            }
        }
    }
}
