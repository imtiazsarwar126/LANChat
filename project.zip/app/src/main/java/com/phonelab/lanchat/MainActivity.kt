package com.phonelab.lanchat

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private var net: Net? = null
    private val msgs = mutableListOf<Msg>()
    private lateinit var adapter: MsgAdapter
    private lateinit var list: RecyclerView
    private lateinit var online: TextView
    private lateinit var input: EditText
    private lateinit var btnMic: Button
    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    private var player: MediaPlayer? = null
    private var myName = ""

    private val micPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startRec() else toast("Microphone permission denied")
        }
    private val pickFile =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) sendUri(uri, "F")
        }
    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) sendUri(uri, "I")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        list = findViewById(R.id.list)
        online = findViewById(R.id.online)
        input = findViewById(R.id.input)
        btnMic = findViewById(R.id.btnMic)

        adapter = MsgAdapter(msgs, { openFile(it) }, { play(it) })
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<Button>(R.id.btnFile).setOnClickListener { pickFile.launch("*/*") }
        findViewById<Button>(R.id.btnImage).setOnClickListener { pickImage.launch("image/*") }
        findViewById<Button>(R.id.btnSend).setOnClickListener { sendText() }
        btnMic.setOnClickListener { toggleRecord() }

        val prefs = getSharedPreferences("chat", MODE_PRIVATE)
        val saved = prefs.getString("name", null)
        if (saved == null) askName(prefs) else startNet(prefs, saved)
    }

    private fun askName(prefs: SharedPreferences) {
        val et = EditText(this)
        et.hint = "Your name"
        AlertDialog.Builder(this)
            .setTitle("Welcome! Enter your name")
            .setView(et)
            .setCancelable(false)
            .setPositiveButton("Start") { _, _ ->
                var n = et.text.toString().trim()
                if (n.isEmpty()) n = "User" + (100..999).random()
                prefs.edit().putString("name", n).apply()
                startNet(prefs, n)
            }
            .show()
    }

    private fun startNet(prefs: SharedPreferences, name: String) {
        myName = name
        var id = prefs.getString("id", null)
        if (id == null) {
            id = UUID.randomUUID().toString()
            prefs.edit().putString("id", id).apply()
        }
        net = Net(
            this, id, name,
            onMessage = { m -> runOnUiThread { addMsg(m) } },
            onPeers = { runOnUiThread { updateOnline() } }
        )
        net?.start()
        updateOnline()
    }

    private fun updateOnline() {
        val names = net?.peers?.values?.map { it.name } ?: emptyList()
        online.text = if (names.isEmpty()) {
            "You: $myName  •  Searching for friends on this Wi-Fi..."
        } else {
            "You: $myName  •  Online: " + names.joinToString(", ")
        }
    }

    private fun addMsg(m: Msg) {
        msgs.add(m)
        adapter.notifyItemInserted(msgs.size - 1)
        list.scrollToPosition(msgs.size - 1)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- send text / files ----------

    private fun sendText() {
        val n = net ?: return
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        if (n.peers.isEmpty()) toast("Nobody else is online yet")
        n.send("T", t, null)
        addMsg(Msg("You", "T", t, null, true))
        input.setText("")
    }

    private fun sendUri(uri: Uri, type: String) {
        val n = net ?: return
        Thread {
            try {
                var name = "file"
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0) name = c.getString(i)
                    }
                }
                val clean = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val f = File(n.mediaDir(), "${System.currentTimeMillis()}_$clean")
                contentResolver.openInputStream(uri)?.use { i ->
                    f.outputStream().use { o -> i.copyTo(o) }
                }
                n.send(type, name, f)
                runOnUiThread { addMsg(Msg("You", type, name, f.absolutePath, true)) }
            } catch (e: Exception) {
                runOnUiThread { toast("Could not send file") }
            }
        }.start()
    }

    // ---------- voice messages ----------

    private fun toggleRecord() {
        if (recorder != null) {
            stopRec()
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startRec()
        } else {
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun startRec() {
        val n = net ?: return
        try {
            val f = File(n.mediaDir(), "voice_${System.currentTimeMillis()}.m4a")
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recFile = f
            btnMic.text = "⏹"
            toast("Recording... tap again to send")
        } catch (e: Exception) {
            recorder = null
            toast("Cannot record audio")
        }
    }

    private fun stopRec() {
        val r = recorder ?: return
        val f = recFile
        var ok = true
        try {
            r.stop()
        } catch (e: Exception) {
            ok = false
        }
        r.release()
        recorder = null
        btnMic.text = "🎤"
        if (ok && f != null && f.length() > 0) {
            net?.send("A", f.name, f)
            addMsg(Msg("You", "A", f.name, f.absolutePath, true))
        } else {
            toast("Recording too short")
        }
    }

    private fun play(m: Msg) {
        val p = m.path ?: return
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(p)
                prepare()
                start()
            }
        } catch (e: Exception) {
            toast("Cannot play audio")
        }
    }

    private fun openFile(m: Msg) {
        val p = m.path ?: return
        try {
            val f = File(p)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val mime = MimeTypeMap.getSingleton()
                .getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, mime)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            toast("No app found to open this file")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        net?.stop()
        player?.release()
        try { recorder?.release() } catch (e: Exception) {}
    }
}

class MsgAdapter(
    private val items: List<Msg>,
    private val onOpen: (Msg) -> Unit,
    private val onPlay: (Msg) -> Unit
) : RecyclerView.Adapter<MsgAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val root: LinearLayout = v.findViewById(R.id.root)
        val bubble: LinearLayout = v.findViewById(R.id.bubble)
        val name: TextView = v.findViewById(R.id.name)
        val img: ImageView = v.findViewById(R.id.img)
        val body: TextView = v.findViewById(R.id.body)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_msg, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val m = items[position]
        val textColor = if (m.mine) Color.WHITE else Color.parseColor("#0D2A4D")
        h.root.gravity = if (m.mine) Gravity.END else Gravity.START
        h.bubble.setBackgroundResource(if (m.mine) R.drawable.bubble_out else R.drawable.bubble_in)
        h.bubble.setOnClickListener(null)
        h.bubble.isClickable = false
        h.name.text = if (m.mine) "You" else m.fromName
        h.name.setTextColor(if (m.mine) Color.parseColor("#BBDEFB") else Color.parseColor("#1565C0"))
        h.body.setTextColor(textColor)
        h.img.visibility = View.GONE
        h.body.visibility = View.VISIBLE

        when (m.type) {
            "T" -> h.body.text = m.text
            "I" -> {
                val p = m.path
                if (p != null) {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(p, bounds)
                    var s = 1
                    while (bounds.outWidth / s > 800) s *= 2
                    val bmp = BitmapFactory.decodeFile(
                        p, BitmapFactory.Options().apply { inSampleSize = s }
                    )
                    if (bmp != null) {
                        h.img.setImageBitmap(bmp)
                        h.img.visibility = View.VISIBLE
                        h.body.visibility = View.GONE
                        h.bubble.setOnClickListener { onOpen(m) }
                    } else {
                        h.body.text = "🖼 ${m.text}"
                        h.bubble.setOnClickListener { onOpen(m) }
                    }
                }
            }
            "A" -> {
                h.body.text = "▶  Voice message"
                h.bubble.setOnClickListener { onPlay(m) }
            }
            else -> {
                h.body.text = "📎 ${m.text}\n(tap to open)"
                h.bubble.setOnClickListener { onOpen(m) }
            }
        }
    }
}
